﻿Imports System.IO
Imports Outlook = Microsoft.Office.Interop.Outlook
Imports System.Activities
Imports System.ComponentModel

Namespace EmailRetriever
    Public Class EmailRetrieverClass
        Inherits CodeActivity
        <Category("Input")>
        Public Property InputMailboxName As InArgument(Of String)
        <Category("Output")>
        Public Property DT_EmailBodies_Out As OutArgument(Of DataTable)
        <Category("Output")>
        Public Property DT_EmailAttachments_Out As OutArgument(Of DataTable)

        Public DT_EmailBodies As DataTable
        Public DT_EmailAttachments As DataTable
        Public strMailboxName As String

        Protected Overrides Sub Execute(context As CodeActivityContext)
            strMailboxName = Me.InputMailboxName.Get(context)
            RetrieveEmails()
            Me.DT_EmailAttachments_Out.Set(context, DT_EmailAttachments)
            Me.DT_EmailBodies_Out.Set(context, DT_EmailBodies)
        End Sub

        Public Sub RetrieveEmails()
            Dim email As Outlook.MailItem
            Dim atach As Outlook.Attachment
            Dim oApp As Outlook.Application
            Dim objRecipient As Outlook.Recipient
            Dim sharedInbox As Outlook.Folder
            Dim strEnv As String
            Dim strDomain As String
            Dim strExtension As String
            Dim intFolderCount As Integer

            strEnv = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            Dim strSaveFolder As String = strEnv + "\TempFolder"
            If (Not Directory.Exists(strSaveFolder)) Then
                Directory.CreateDirectory(strSaveFolder)
            End If

            oApp = New Outlook.Application()
            objRecipient = oApp.Session.CreateRecipient(strMailboxName)
            sharedInbox = oApp.Session.GetSharedDefaultFolder(objRecipient, Outlook.OlDefaultFolders.olFolderInbox)
            'sharedInbox = sharedInbox.Folders("Bot – Inbox")
            intFolderCount = 1
            DT_EmailAttachments = New DataTable
            DT_EmailBodies = New DataTable
            DT_EmailAttachments.Columns.Add("Path")
            DT_EmailAttachments.Columns.Add("From")
            DT_EmailBodies.Columns.Add("Body")
            DT_EmailBodies.Columns.Add("From")

            For i = sharedInbox.Items.Count To 1 Step -1
                email = sharedInbox.Items(i)
                strDomain = email.SenderEmailAddress.Substring(email.SenderEmailAddress.IndexOf("@", StringComparison.CurrentCultureIgnoreCase) + 1).ToLower
                Select Case strDomain
                    Case "gm.com"
                        If email.Attachments.Count > 0 Then
                            For Each atach In email.Attachments
                                strExtension = Right(atach.FileName, atach.FileName.Length - atach.FileName.LastIndexOf(".")).ToLower
                                Select Case strExtension
                                    Case ".docx", ".doc", ".xls", ".xlsx"
                                        If (Not Directory.Exists(strSaveFolder + "\" + intFolderCount.ToString)) Then
                                            Directory.CreateDirectory(strSaveFolder + "\" + intFolderCount.ToString)
                                        End If
                                        atach.SaveAsFile(strSaveFolder + "\" + intFolderCount.ToString + "\" + atach.FileName)
                                        DT_EmailAttachments.Rows.Add(strSaveFolder + "\" + intFolderCount.ToString + "\", email.SenderEmailAddress)
                                        intFolderCount = intFolderCount + 1
                                        Exit For
                                    Case Else
                                        'do nothing
                                End Select
                            Next atach
                            'email.Move(sharedInbox.Folders("Bot – Archive"))
                            email.Move(sharedInbox.Parent.Folders("Bot - Archive"))
                        Else
                        End If
                    Case "aptiv.com"
                        DT_EmailBodies.Rows.Add(email.Body, email.SenderEmailAddress)
                        'email.Move(sharedInbox.Folders("Bot – Archive"))
                        email.Move(sharedInbox.Parent.Folders("Bot - Archive"))
                    Case Else
                End Select
            Next
        End Sub
    End Class
End Namespace